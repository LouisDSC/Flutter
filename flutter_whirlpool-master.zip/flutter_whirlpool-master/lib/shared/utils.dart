import 'dart:math';

class Utils {
  static double degToRad(double degrees) {
    return (pi / 180) * degrees;
  }
}
